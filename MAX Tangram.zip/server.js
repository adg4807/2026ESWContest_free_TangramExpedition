const express = require('express');
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const { exec } = require('child_process');

const app = express();
const server = http.createServer(app);
const port = 7080;

// CORS 설정
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

// JSON 파싱 및 정적 파일 설정
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = 'data.json';

// 데이터 저장소 초기화
let data = {
    player1Data: [],
    player2Data: [],
    buttonSelections: {
        selections: [],
        currentSelection: null
    },
    pythonData: {},
    arduinoData: {} // 저장 안 해도 되므로 기본값 유지
};

// 데이터 로드
function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const fileData = fs.readFileSync(DATA_FILE, 'utf8');
            data = JSON.parse(fileData);
            console.log('데이터를 성공적으로 로드했습니다.');
        }
    } catch (error) {
        console.error('데이터 로드 중 오류:', error);
    }
}

// 데이터 저장 (아두이노 데이터는 저장 안 함)
function saveData() {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
        console.log('데이터를 성공적으로 저장했습니다.');
    } catch (error) {
        console.error('데이터 저장 중 오류:', error);
    }
}

// 초기 데이터 로드
loadData();

// WebSocket 서버 설정
const wss = new WebSocket.Server({
    server,
    clientTracking: true,
    verifyClient: (info, cb) => cb(true) // 모든 연결 허용
});

// WebSocket 연결 처리
wss.on('connection', (ws, req) => {
    console.log('새로운 클라이언트 연결:', req.socket.remoteAddress, req.url);
    ws.send(JSON.stringify({ type: 'state', data }));
    ws.on('error', (error) => console.error('WebSocket 에러:', error));
    ws.on('close', (code, reason) => console.log(`클라이언트 연결 종료: 코드 ${code}, 사유: ${reason}`));
});

// 데이터 브로드캐스트 함수
function broadcastData(type, payload) {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type, data: payload }));
        }
    });
}

// REST API 엔드포인트
// 아두이노 데이터 수신 (저장 제거)
app.post('/api/arduino', (req, res) => {
    const { diagram, x, y, z } = req.body;
    console.log('아두이노 데이터 수신:', { diagram, x, y, z });

    if (typeof diagram !== 'number' || typeof x !== 'number' || 
        typeof y !== 'number' || typeof z !== 'number') {
        return res.status(400).json({ error: '잘못된 데이터 형식입니다. 숫자로 보내주세요.' });
    }

    // diagram 값 포함하여 브로드캐스트
    broadcastData('arduino', { diagram, x, y, z });
    res.json({ message: '데이터 수신 완료', receivedData: { diagram, x, y, z } });
});

app.get('/api/arduino', (req, res) => res.json(data.arduinoData));

app.get('/api/data', (req, res) => res.json(data));

app.get('/api/selections', (req, res) => res.json(data.buttonSelections));

app.delete('/api/selections', (req, res) => {
    data.buttonSelections.selections = [];
    data.buttonSelections.currentSelection = null;
    saveData();
    broadcastData('button', data.buttonSelections);
    res.json({ message: '히스토리가 삭제되었습니다.' });
});

app.post('/api/trigger-projection', (req, res) => {
    console.log('프로젝션 매핑 실행 요청 수신');
    exec('path/to/your/program', (error, stdout, stderr) => {
        if (error) {
            console.error(`프로그램 실행 오류: ${error.message}`);
            return res.status(500).json({ message: '프로그램 실행 오류' });
        }
        if (stderr) {
            console.error(`프로그램 실행 중 오류: ${stderr}`);
            return res.status(500).json({ message: '프로그램 실행 중 오류' });
        }
        console.log(`프로그램 실행 결과: ${stdout}`);
        res.json({ message: '프로젝션 매핑이 실행되었습니다.' });
    });
});

// 파이썬 데이터 수신
app.post('/api/python', (req, res) => {
    const receivedData = req.body;
    console.log('파이썬 데이터 수신:', { receivedData });
    broadcastData('python', {receivedData });
    res.json({ message: '파이썬 데이터 수신 완료', receivedData: { receivedData } });
});

app.get('/api/python', (req, res) => res.json(data.pythonData));

// 메인 페이지
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'main.html')));

// 게임 설정
app.get('/api/settings', (req, res) => {
    res.json({
        selectedMode: data.selectedMode || "기본",
        selectedTime: data.selectedTime || 30,
        selectedDifficulty: data.selectedDifficulty || "중간",
        selectedPattern: data.selectedPattern || "선택 안됨",
        selectedTheme: data.selectedTheme || "기본"
    });
});

app.post('/api/settings', (req, res) => {
    const { mode, time, difficulty, pattern, theme } = req.body;
    console.log('수신된 설정:', { mode, time, difficulty, pattern, theme });

    if (mode) data.selectedMode = mode;
    if (theme) data.selectedTheme = theme;
    if (time) data.selectedTime = time;
    if (difficulty) data.selectedDifficulty = difficulty;
    if (pattern) data.selectedPattern = pattern;

    saveData();
    res.json({ message: '설정이 성공적으로 저장되었습니다.', settings: { time, difficulty, pattern, theme } });
});

// 서버 시작
server.listen(port, () => {
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
}).on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`포트 ${port}가 이미 사용 중입니다.`);
    } else {
        console.error('서버 시작 중 오류 발생:', err);
    }
});

// WebSocket 서버 에러 처리
wss.on('error', (error) => console.error('WebSocket 서버 오류:', error));